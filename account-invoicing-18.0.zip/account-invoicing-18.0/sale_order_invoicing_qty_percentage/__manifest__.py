# Copyright 2023 Tecnativa - Pedro M. Baeza
# Copyright 2024 Tecnativa - Carolina Fernandez
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Sales order invoicing by percentage of the quantity",
    "version": "18.0.1.0.0",
    "category": "Sales Management",
    "license": "AGPL-3",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/account-invoicing",
    "depends": ["sale"],
    "data": ["wizards/sale_advance_payment_inv_views.xml"],
    "installable": True,
    "maintainers": ["pedrobaeza"],
}
