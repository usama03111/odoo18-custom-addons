# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    access_token = fields.Char(string="Access Token", config_parameter="codex_whatsapp_connector.access_token")
    whatsapp_phone_id = fields.Char(string="WhatsApp Phone Number ID", config_parameter="codex_whatsapp_connector.phone_number_id")
    webhook_verify_token = fields.Char(string="Webhook Verify Token", config_parameter="codex_whatsapp_connector.webhook_verify_token", help="Token for webhook verification from Meta")
    wa_default_agent_user_ids = fields.Many2many(
        'res.users',
        string="Default WhatsApp Agents",
        help="Users who will be auto-added to new WhatsApp channels when a customer sends the first message."
    )
    wa_button_models_ids = fields.Many2many(
        'ir.model',
        string="Models with WhatsApp Button",
        help="Only these models' chatters will show the WhatsApp button. Leave empty to show on all models."
    )
    
    # Template configuration for first contact
    template_name = fields.Char(
        string="WhatsApp Template Name", 
        config_parameter="codex_whatsapp_connector.template_name",
        default="hello_world",
        help="Name of the approved WhatsApp template to use for first contact (e.g., hello_world, customer_support)"
    )
    template_language = fields.Char(
        string="Template Language Code", 
        config_parameter="codex_whatsapp_connector.template_language",
        default="en_US",
        help="Language code for the template (e.g., en_US, es_ES, fr_FR)"
    )
    api_version = fields.Char(
        string="WhatsApp API Version", 
        config_parameter="codex_whatsapp_connector.api_version",
        default="v22.0",
        help="WhatsApp API version (e.g., v22.0, v23.0)"
    )
    
    # webhook_url = fields.Char(string="Webhook URL", config_parameter="codex_whatsapp_connector.webhook_url",
    #                           help="Enter your webhook URL (e.g., https://yourdomain.com/whatsapp/webhook)")
    webhook_url = fields.Char(
        string="Webhook URL",
        compute="_compute_webhook_url",
        config_parameter="codex_whatsapp_connector.webhook_url",
        help="Dynamically generated Webhook URL (https://yourdomain.com/whatsapp/webhook)"
    )

    @api.depends()
    def _compute_webhook_url(self):
        """Dynamically generate the webhook URL based on Odoo's base URL"""
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        for rec in self:
            rec.webhook_url = f"{base_url}/whatsapp/webhook" if base_url else ''

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        icp = self.env['ir.config_parameter'].sudo()
        import json
        users_json = icp.get_param('codex_whatsapp_connector.wa_default_agent_user_ids', default='[]')
        try:
            user_ids = json.loads(users_json) if users_json else []
        except Exception:
            user_ids = []
        models_json = icp.get_param('codex_whatsapp_connector.wa_button_models', default='[]')
        try:
            model_names = json.loads(models_json) if models_json else []
        except Exception:
            model_names = []
        model_ids = []
        if model_names:
            Model = self.env['ir.model'].sudo()
            existing = Model.search([('model', 'in', model_names)])
            model_ids = existing.ids
        res.update({
            'wa_default_agent_user_ids': [(6, 0, user_ids)],
            'wa_button_models_ids': [(6, 0, model_ids)],
        })
        return res

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        icp = self.env['ir.config_parameter'].sudo()
        import json
        user_ids = self.wa_default_agent_user_ids.ids if self.wa_default_agent_user_ids else []
        icp.set_param('codex_whatsapp_connector.wa_default_agent_user_ids', json.dumps(user_ids))
        # Persist models by technical names, not ids
        model_names = []
        if self.wa_button_models_ids:
            model_names = [m.model for m in self.wa_button_models_ids if m.model]
        icp.set_param('codex_whatsapp_connector.wa_button_models', json.dumps(model_names))