# Copyright 2016-2019 Tecnativa - Pedro M. Baeza
# Copyright 2018 Tecnativa - Carlos Dauden
# Copyright 2019 ACSONE SA/NV
# Copyright 2024 Tecnativa - Carolina fernandez
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Variable quantity in contract recurrent invoicing",
    "version": "18.0.1.0.0",
    "category": "Contract Management",
    "license": "AGPL-3",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/contract",
    "depends": ["contract"],
    "data": [
        "security/ir.model.access.csv",
        "views/contract_template_line.xml",
        "views/contract_line_formula.xml",
        "views/contract_line_views.xml",
        "views/contract_template.xml",
        "views/contract.xml",
    ],
    "installable": True,
}
