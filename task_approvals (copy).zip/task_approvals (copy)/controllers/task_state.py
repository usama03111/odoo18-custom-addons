from odoo import http
from odoo.http import request
from odoo.addons.project.controllers.portal import CustomerPortal

class CustomPortalTask(CustomerPortal):

    @http.route(['/my/tasks'], type='http', auth="user", website=True)
    def portal_my_tasks(self, **kwargs):
        domain = [('user_ids', 'in', request.env.user.id)]

        # Filtering by custom state
        state_filter = kwargs.get('state')
        if state_filter:
            domain += [('state', '=', state_filter)]
        print("domain",domain)
        tasks = request.env['project.task'].search(domain)

        values = {
            'tasks': tasks,
            'state_filter': state_filter,
        }
        print("vals", values)
        return request.render("project.portal_my_tasks", values)
