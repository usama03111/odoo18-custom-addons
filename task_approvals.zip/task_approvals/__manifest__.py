# -*- coding: utf-8 -*-

{
    'name': "task Approval",
    "version": "18.0.0.6",
    'author': 'Task Solution',
    'company': 'Task Solution',
    'website': 'http://www.altapetesolution.com',
    'summary': 'Purchase Approval',
    'license': 'LGPL-3',
    "description": """Purchase Approval and only CEO can approve""",
    'depends': ['sale', 'purchase', 'account', 'product','project'],
    'data': [
        'security/ir.model.access.csv',
        'security/group.xml',
        'data/mail_activity_type_data.xml',
        'data/sequence_data.xml',
        # 'views/task_approval_approver.xml',
        'views/task_approver_views.xml',
        'views/task_category_approver_views.xml',
        'views/task_request_view.xml',
        # 'wizard/reason_wizard_view.xml',
    ],
    'images': [''],
    "auto_install": False,
    "installable": True,

}
