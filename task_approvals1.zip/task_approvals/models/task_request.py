from odoo import models, api, fields, Command, _
from odoo.api import ondelete
from odoo.exceptions import UserError, ValidationError
import logging

_logger = logging.getLogger(__name__)


class ProjectTask(models.Model):
    _inherit = 'project.task'

    approver_id = fields.Many2one('task.approver', required=True, tracking=True)
    approver_sequence = fields.Boolean(related="approver_id.approver_sequence")
    automated_sequence = fields.Boolean(related="approver_id.automated_sequence")
    approval_minimum = fields.Integer(related="approver_id.approval_minimum")
    reason = fields.Char('Reason', tracking=True)

    state = fields.Selection(selection_add=[
        ('draft', 'Draft'),
        ('pending', 'To Approve'),
        ('approved', 'Sent To CEO'),
        ('ceo_approve', 'CEO Approval'),
        ('refused', 'Refused'),
        ('done', 'Completed'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=False, index=True, copy=False, default='draft', tracking=True,
        ondelete={'draft': 'set default', 'pending': 'set default', 'approved': 'set default',
                  'ceo_approve': 'set default',
                  'refused': 'set default', 'done': 'set default', 'cancel': 'set default'}
    )

    user_status = fields.Selection([
        ('new', 'New'),
        ('pending', 'To Approve'),
        ('waiting', 'Waiting'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
        ('cancel', 'Cancel')
    ], compute="_compute_user_status")

    date_confirmed = fields.Datetime(string="Date Confirmed")

    approver_ids = fields.One2many('task.approval.approver', 'task_id', string="Approvers",
                                   compute='_compute_approver_ids', store=True, readonly=False)

    @api.model
    def _read_group_request_status(self, stages, domain, order):
        request_status_list = dict(self._fields['request_status'].selection).keys()
        return request_status_list

    def send_for_approvals(self):
        self.ensure_one()
        if len(self.approver_ids) < self.approval_minimum:
            raise UserError(_("You have to add at least %s approvers to confirm your task.", self.approval_minimum))

        approvers = self.approver_ids
        if self.approver_sequence:
            approvers = approvers.filtered(lambda a: a.status in ['new', 'pending', 'waiting'])
            approvers[1:].sudo().write({'status': 'waiting'})
            approvers = approvers[0] if approvers and approvers[0].status != 'pending' else self.env[
                'task.approval.approver']
        else:
            approvers = approvers.filtered(lambda a: a.status == 'new')
        approvers._create_activity()
        self.sudo().write({'state': 'pending', 'date_confirmed': fields.Datetime.now()})
        approvers.sudo().write({'status': 'pending'})

    def _update_task_state(self, statuses, required_approved, minimal_approved):
        """Helper method to determine task state based on approvals"""
        if 'refused' in statuses:
            return 'refused'
        elif 'new' in statuses:
            return 'draft'
        elif statuses.count('approved') >= minimal_approved and required_approved:
            return 'approved'
        return 'pending'

    def action_approve(self, approver=None):
        self._ensure_can_approve()
        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(lambda a: a.user_id == self.env.user)

        approver.write({'status': 'approved'})
        self._update_next_approvers('pending', approver, only_next_approver=True)
        self._get_user_approval_activities(user=self.env.user).action_feedback()

        for task in self:
            statuses = task.mapped('approver_ids.status')
            required_approved = all(a.status == 'approved' for a in task.approver_ids.filtered('required'))
            minimal_approved = task.approval_minimum if len(statuses) >= task.approval_minimum else len(statuses)

            state = self._update_task_state(statuses, required_approved, minimal_approved)
            task.write({'state': state})

            if state == 'approved':
                self._notify_ceo_activity(task)

    def _notify_ceo_activity(self, task):
        """Create activity for CEO approval"""
        ceo_group = self.env.ref('task_approvals.task_group_ceo')
        for ceo_user in ceo_group.users:
            if not task._get_user_approval_activities(ceo_user):
                self.env['mail.activity'].create({
                    'res_model_id': self.env['ir.model']._get_id('project.task'),
                    'res_id': task.id,
                    'user_id': ceo_user.id,
                    'summary': _('Task Approval Required'),
                    'note': _('Task (%s) needs your approval.') % task.name,
                    'activity_type_id': self.env.ref('task_approvals.mail_activity_data_approval_task').id,
                    'date_deadline': fields.Date.today(),
                })

    def _update_next_approvers(self, new_status, approver, only_next_approver, cancel_activities=False):
        approvers_updated = self.env['task.approval.approver']
        for task in self.filtered('approver_sequence'):
            current = task.approver_ids & approver
            next_approvers = task.approver_ids.filtered(lambda a: a.status not in ['approved', 'refused'] and (
                    a.sequence > current.sequence or (a.sequence == current.sequence and a.id > current.id)))
            if only_next_approver and next_approvers:
                next_approvers = next_approvers[0]
            approvers_updated |= next_approvers
        approvers_updated.sudo().write({'status': new_status})
        if new_status == 'pending':
            approvers_updated._create_activity()
        if cancel_activities:
            approvers_updated.task_id._cancel_activities()

    def _cancel_activities(self):
        activity_type = self.env.ref('task_approvals.mail_activity_data_approval_task')
        self.activity_ids.filtered(lambda a: a.activity_type_id == activity_type).unlink()

    def _get_user_approval_activities(self, user):
        return self.env['mail.activity'].search([
            ('res_model', '=', 'project.task'),
            ('res_id', 'in', self.ids),
            ('activity_type_id', '=', self.env.ref('task_approvals.mail_activity_data_approval_task').id),
            ('user_id', '=', user.id)
        ])

    def action_refuse(self, approver=None):
        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(lambda a: a.user_id == self.env.user)
        approver.write({'status': 'refused'})
        self.write({'state': 'refused'})
        self._update_next_approvers('refused', approver, only_next_approver=False, cancel_activities=True)
        self._get_user_approval_activities(user=self.env.user).action_feedback()

    def action_withdraw(self, approver=None):
        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(lambda a: a.user_id == self.env.user)
        self._update_next_approvers('waiting', approver, only_next_approver=False, cancel_activities=True)
        approver.write({'status': 'pending'})

    @api.depends('approver_ids.status')
    def _compute_user_status(self):
        for task in self:
            task.user_status = task.approver_ids.filtered(lambda a: a.user_id == self.env.user).status

    def _ensure_can_approve(self):
        if any(task.approver_sequence and task.user_status == 'waiting' for task in self):
            raise ValidationError(_('You cannot approve before the previous approver.'))

    @api.model
    def _update_approver_vals(self, approver_id_vals, approver, new_required, new_sequence):
        if approver.required != new_required or approver.sequence != new_sequence:
            approver_id_vals.append(
                Command.update(approver.id, {'required': new_required, 'sequence': new_sequence}))

    @api.model
    def _create_or_update_approver(self, user_id, users_to_approver, approver_id_vals, required, sequence):
        if user_id not in users_to_approver.keys():
            approver_id_vals.append(Command.create({
                'user_id': user_id,
                'status': 'new',
                'required': required,
                'sequence': sequence,
            }))
        else:
            current_approver = users_to_approver.pop(user_id)
            self._update_approver_vals(approver_id_vals, current_approver, required, sequence)

    def action_ceo_approve(self):
        self.ensure_one()
        if not self.env.user.has_group('task_approvals.task_group_ceo'):
            raise UserError(_("Only CEO can approve this task."))

        self._ensure_can_approve()
        activities = self._get_user_approval_activities(user=self.env.user)
        if activities:
            activities.action_feedback(feedback=_("Task approved by CEO"))

        vals = {'state': 'done', 'date_confirmed': fields.Datetime.now()}
        self.write(vals)

        if self.user_ids and self.user_ids.partner_id:
            try:
                self.message_subscribe([self.user_ids.partner_id.id])
            except Exception:
                pass
        return True

    @api.depends('approver_id')
    def _compute_approver_ids(self):
        for task in self:
            current = {a.user_id.id: a for a in task.approver_ids}
            category = {a.user_id.id: a for a in task.approver_id.approver_ids}
            new_vals = []

            for user_id in category:
                if user_id not in current:
                    new_vals.append(Command.create({
                        'user_id': user_id,
                        'status': 'new',
                        'required': category[user_id].required,
                        'sequence': category[user_id].sequence,
                    }))
                else:
                    a = current.pop(user_id)
                    if a.required != category[user_id].required or a.sequence != category[user_id].sequence:
                        new_vals.append(Command.update(a.id, {
                            'required': category[user_id].required,
                            'sequence': category[user_id].sequence,
                        }))
            for remaining in current.values():
                new_vals.append(Command.update(remaining.id, {'required': False, 'sequence': 1000}))

            task.update({'approver_ids': new_vals})

    # def button_confirm(self):
    #     # Log warning if email is not configured
    #     if not self.env.user.email:
    #         _logger.warning(
    #             f"User {self.env.user.name} does not have an email configured. Some notifications may not be sent.")
    #
    #     for task in self:
    #         if task.state not in ['draft', 'sent', 'approved']:
    #             continue
    #
    #         # Update the state to done since CEO has approved
    #         task.write({'state': 'done'})
    #
    #         try:
    #             # Create activity for task completion notification
    #             self.env['mail.activity'].create({
    #                 'res_model_id': self.env['ir.model']._get_id('project.task'),
    #                 'res_id': task.id,
    #                 'user_id': task.user_ids.id if task.user_ids else self.env.user.id,
    #                 'summary': 'Task Approved and Completed',
    #                 'note': f'Task ({task.name}) has been approved by CEO and marked as completed.',
    #                 'activity_type_id': self.env.ref('task_approvals.mail_activity_data_approval_task').id,
    #                 'date_deadline': fields.Date.today(),
    #             })
    #
    #             # Try to subscribe the task assignee if they have email configured
    #             if task.user_ids and task.user_ids.partner_id:
    #                 try:
    #                     task.message_subscribe([task.user_ids.partner_id.id])
    #                 except Exception as e:
    #                     _logger.warning(
    #                         f"Could not subscribe user {task.user_ids.name} to task notifications: {str(e)}")
    #
    #         except Exception as e:
    #             _logger.error(f"Error in task confirmation process: {str(e)}")
    #             # Continue with the process even if notification fails
    #             pass
    #
    #     return True

    @api.constrains('approver_ids')
    def _check_approver_ids(self):
        for request in self:
            # make sure the approver_ids are unique per request
            if len(request.approver_ids) != len(request.approver_ids.user_id):
                raise UserError(_("You cannot assign the same approver multiple times on the same request."))

    def write(self, vals):
        res = super().write(vals)
        if 'approver_ids' in vals:
            resequence = self.filtered(lambda t: t.approver_sequence and t.state == 'pending')
            for task in resequence:
                if not task.approver_ids.filtered(lambda a: a.status == 'pending'):
                    pending = task.approver_ids.filtered(lambda a: a.status == 'waiting')
                    if pending:
                        pending[0].write({'status': 'pending'})
                        pending[0]._create_activity()
        return res


class TaskApprovalApprover(models.Model):
    _name = 'task.approval.approver'
    _description = 'Task Approver Line'
    _order = 'sequence, id'

    sequence = fields.Integer('Sequence', default=10)
    user_id = fields.Many2one('res.users', string="User", required=True, check_company=True,
                              domain="[('id', 'not in', existing_request_user_ids)]")
    existing_request_user_ids = fields.Many2many('res.users', compute='_compute_existing_request_user_ids')
    status = fields.Selection([
        ('new', 'New'),
        ('pending', 'To Approve'),
        ('waiting', 'Waiting'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
        ('cancel', 'Cancel')
    ], string="Status", default="new", readonly=True)

    task_id = fields.Many2one('project.task', string="Task", ondelete='cascade', check_company=True)
    company_id = fields.Many2one(related='task_id.company_id', store=True, readonly=True, index=True)
    required = fields.Boolean(default=False, readonly=True)
    category_approver = fields.Boolean(compute='_compute_category_approver')
    can_edit = fields.Boolean(compute='_compute_can_edit')
    can_edit_user_id = fields.Boolean(compute='_compute_can_edit')

    def action_approve(self):
        self.task_id.action_approve(self)

    def action_refuse(self):
        self.task_id.action_refuse(self)

    def _create_activity(self):
        for approver in self:
            approver.task_id.activity_schedule(
                'task_approvals.mail_activity_data_approval_task',
                user_id=approver.user_id.id)

    @api.depends('task_id.approver_ids.user_id')
    def _compute_existing_request_user_ids(self):
        for approver in self:
            approver.existing_request_user_ids = approver.task_id.approver_ids.mapped('user_id')._origin

    @api.depends('category_approver', 'user_id')
    def _compute_category_approver(self):
        for a in self:
            a.category_approver = a.user_id in a.task_id.approver_id.approver_ids.mapped('user_id')

    @api.depends_context('uid')
    def _compute_can_edit(self):
        is_user = self.env.user.has_group('task_approvals.task_group_approval_user')
        for approval in self:
            approval.can_edit = not approval.user_id or not approval.category_approver or is_user
            approval.can_edit_user_id = is_user
