/** @odoo-module **/

import { KanbanRecord } from "@web/views/kanban/kanban_record";

const patchTaskDrag = {
    setup() {
        if (this.env.model === "project.task") {
            this.isDraggable = () => {
                const state = this.props.record.data.state;
                return state === "1_done"; // Only allow drag if state == '1_done'
            };
        }
    },
};

KanbanRecord.include(patchTaskDrag);
